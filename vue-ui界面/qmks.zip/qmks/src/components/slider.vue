<template>
	<div class="mui-content">
			    <div class="mui-slider">
			        <div class="mui-slider-group mui-slider-loop">
			        	<!-- 额外增加的一个节点(循环轮播：第一个节点是最后一个图文表格) -->
			            <div class="mui-slider-item mui-slider-item-duplicate">
			                <ul class="mui-table-view mui-grid-view">
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/cbd.jpg">
			                            <div class="mui-media-body">Color of SIP CBD</div></a></li>
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/yuantiao.jpg">
			                            <div class="mui-media-body">静静看这世界</div></a></li>
			                </ul>
			            </div>
			            <div class="mui-slider-item">
			                <ul class="mui-table-view mui-grid-view">
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/shuijiao.jpg">
			                            <div class="mui-media-body">幸福就是可以一起睡觉</div></a></li>
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/muwu.jpg">
			                            <div class="mui-media-body">想要一间这样的木屋，静静的喝咖啡</div></a></li>
			                </ul>
			            </div>
			            <div class="mui-slider-item">
			                <ul class="mui-table-view mui-grid-view">
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/cbd.jpg">
			                            <div class="mui-media-body">Color of SIP CBD</div></a></li>
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/yuantiao.jpg">
			                            <div class="mui-media-body">静静看这世界</div></a></li>
			                </ul>
			            </div>
			            <!-- 额外增加的一个节点(循环轮播：最后一个节点是第一个图文表格) -->
			            <div class="mui-slider-item mui-slider-item-duplicate">
			                <ul class="mui-table-view mui-grid-view">
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/shuijiao.jpg">
			                            <div class="mui-media-body">幸福就是可以一起睡觉</div></a></li>
			                    <li class="mui-table-view-cell mui-media mui-col-xs-6"><a href="#"><img class="mui-media-object" src="../images/muwu.jpg">
			                            <div class="mui-media-body">想要一间这样的木屋，静静的喝咖啡</div></a></li>
			                </ul>
			            </div>
			        </div>
			        <div class="mui-slider-indicator" style="position: static;background-color: #fff;">
			            <span class="mui-action mui-action-previous mui-icon mui-icon-back"></span>
			            <div class="mui-number">
			                <span>1</span> / 2
			            </div>
			            <span class="mui-action mui-action-next mui-icon mui-icon-forward"></span>
			        </div>
			    </div>
			</div>
</template>

<script src="../assets/js/mui.min.js"></script>
<script>
    mui.init();
</script>

<style>
</style>
